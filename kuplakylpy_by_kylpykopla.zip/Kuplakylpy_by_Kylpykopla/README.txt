Made with love at Graffathon 2019, Urban Mill, Espoo. 2019-06-09.

Authors:
Anna Kuokkanen
Atte Haarakangas
Janne Hiiskoski
Kim Högnabba
Riku Rajaniemi

Music:
random philosophy - more love for all (dark edit)
